package com.borsh.ai;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Порт server.py: Gemini первым, при сбое — запасной Dark API.
 * Ключи читаются из BuildConfig-подобных констант (зашиты в APK).
 */
final class Proxy {

    static final String GEMINI_KEY = "AQ.Ab8RN6LqaMn5xsvKyanWhdKfySAR-otHEB0SC9j7kNlMCxWjQQ";
    static final String DARK_KEY = "tc_live_8f8586f7642f2c6f4df219b63ed675fde909cba0d7baa642";
    static final String GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/openai";
    static final String DARK_BASE = "https://darkapi.shop/v1";

    // Бесплатный резерв без ключа: работает там, где Gemini закрыт по региону.
    static final String POLL_BASE = "https://text.pollinations.ai";
    static final String POLL_MODEL = "openai-fast";

    private static volatile long geminiBlockedUntil = 0;

    static boolean geminiBlocked() {
        return System.currentTimeMillis() < geminiBlockedUntil;
    }

    static void blockGemini(long millis) {
        geminiBlockedUntil = System.currentTimeMillis() + millis;
    }

    static boolean isGeo(String message) {
        String m = message == null ? "" : message.toLowerCase();
        return m.contains("location is not supported") || m.contains("user location")
                || m.contains("failed_precondition");
    }

    static String withModel(JSONObject payload, String model) {
        try {
            JSONObject copy = new JSONObject(payload.toString());
            copy.put("model", model);
            return copy.toString();
        } catch (Exception e) {
            return payload.toString();
        }
    }

    private static final String UA = "Mozilla/5.0 (Linux; Android) BorshAI/1.0";
    private static final Pattern GEMINI_RE =
            Pattern.compile("^(models/)?(gemini|imagen|gemma)", Pattern.CASE_INSENSITIVE);

    // Порядок важен: приложение берёт первую подходящую модель из списка.
    // Lite стоит первым: он отвечает за ~0.6 с, остальные — 4…6 с (долгое «размышление»).
    private static final String[] PREFERRED = {
            "gemini-3.1-flash-lite", "gemini-3.5-flash", "gemini-3.8-flash",
            "gemini-3.7-flash", "gemini-3.6-flash", "gemini-flash-latest"
    };

    private static final String FALLBACK_MODEL = "gemini-3.5-flash";

    private static volatile List<String> darkIds = null;
    private static volatile String modelsCache = null;
    private static volatile long modelsCacheAt = 0;
    private static final long MODELS_TTL = 10 * 60 * 1000L;

    static final class Result {
        int code;
        String body;
        String ctype = "application/json";

        Result(int code, String body, String ctype) {
            this.code = code;
            this.body = body;
            if (ctype != null && ctype.length() > 0) this.ctype = ctype;
        }
    }

    private Proxy() {
    }

    // ------------------------------------------------------------------ http

    static Result exec(String url, String key, String method, String body, int readTimeout) {
        return exec(url, key, method, body, 20000, readTimeout);
    }

    static Result exec(String url, String key, String method, String body, int connectTimeout, int readTimeout) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(connectTimeout);
            c.setReadTimeout(readTimeout);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("User-Agent", UA);
            if (key != null && key.length() > 0) {
                c.setRequestProperty("Authorization", "Bearer " + key);
            }
            c.setRequestMethod(method);
            if (body != null) {
                c.setDoOutput(true);
                byte[] raw = body.getBytes(StandardCharsets.UTF_8);
                c.setFixedLengthStreamingMode(raw.length);
                OutputStream os = c.getOutputStream();
                os.write(raw);
                os.flush();
                os.close();
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = readAll(in);
            text = unwrapArrayError(text);
            if (text.length() == 0) {
                text = "{\"error\":{\"message\":\"HTTP " + code + "\"}}";
            }
            String ctype = c.getHeaderField("Content-Type");
            return new Result(code, text, ctype);
        } catch (Exception e) {
            return new Result(502, "{\"error\":{\"message\":" + JSONObject.quote(
                    "Нет связи с сервисом: " + e.getMessage()) + "}}", "application/json");
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Gemini иногда отдаёт ошибку массивом: [{"error":{...}}]. */
    private static String unwrapArrayError(String text) {
        if (text == null) return "";
        String t = text.trim();
        if (!t.startsWith("[")) return text;
        try {
            JSONArray arr = new JSONArray(t);
            if (arr.length() > 0) return arr.getJSONObject(0).toString();
        } catch (Exception ignored) {
        }
        return text;
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192];
        int n;
        while ((n = in.read(chunk)) > 0) buf.write(chunk, 0, n);
        in.close();
        return buf.toString("UTF-8");
    }

    private static String errorText(String body) {
        try {
            return new JSONObject(body).getJSONObject("error").optString("message", "");
        } catch (Exception e) {
            return "";
        }
    }

    // ---------------------------------------------------------------- models

    static Result models() {
        long now = System.currentTimeMillis();
        if (modelsCache != null && now - modelsCacheAt < MODELS_TTL) {
            return new Result(200, modelsCache, "application/json");
        }

        // Dark API тянем параллельно и с коротким таймаутом: если он недоступен,
        // список моделей не должен ждать минуту.
        final List<JSONObject> darkItems = new ArrayList<JSONObject>();
        Thread darkThread = null;
        if (DARK_KEY.length() > 0) {
            darkThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    Result r = exec(DARK_BASE + "/models", DARK_KEY, "GET", null, 4000, 6000);
                    if (r.code == 200) {
                        try {
                            JSONArray data = new JSONObject(r.body).optJSONArray("data");
                            for (int i = 0; data != null && i < data.length(); i++) {
                                darkItems.add(data.getJSONObject(i));
                            }
                        } catch (Exception ignored) {
                        }
                    }
                }
            });
            darkThread.setDaemon(true);
            darkThread.start();
        }

        List<JSONObject> items = new ArrayList<JSONObject>();
        List<String> problems = new ArrayList<String>();
        Map<String, JSONObject> gemini = new LinkedHashMap<String, JSONObject>();

        if (GEMINI_KEY.length() > 0) {
            Result r = exec(GEMINI_BASE + "/models", GEMINI_KEY, "GET", null, 8000, 15000);
            if (r.code == 200) {
                try {
                    JSONArray data = new JSONObject(r.body).optJSONArray("data");
                    for (int i = 0; data != null && i < data.length(); i++) {
                        String id = data.getJSONObject(i).optString("id", "");
                        id = id.replaceFirst("^models/", "");
                        if (id.length() > 0 && !gemini.containsKey(id)) {
                            JSONObject m = new JSONObject();
                            m.put("id", id);
                            m.put("object", "model");
                            m.put("owned_by", "google");
                            gemini.put(id, m);
                        }
                    }
                } catch (Exception e) {
                    problems.add("Gemini: непонятный ответ");
                }
            } else {
                problems.add("Gemini: " + (errorText(r.body).length() > 0 ? errorText(r.body) : "HTTP " + r.code));
            }
        }

        // сначала быстрые и рабочие модели, потом остальные
        for (String id : PREFERRED) {
            JSONObject m = gemini.remove(id);
            if (m != null) items.add(m);
        }
        items.addAll(gemini.values());

        if (darkThread != null) {
            try {
                darkThread.join(4000);
            } catch (InterruptedException ignored) {
            }
            items.addAll(darkItems);
        }

        boolean hasPoll = false;
        for (JSONObject m : items) {
            if (POLL_MODEL.equals(m.optString("id", ""))) hasPoll = true;
        }
        if (!hasPoll) {
            try {
                JSONObject pm = new JSONObject();
                pm.put("id", POLL_MODEL);
                pm.put("object", "model");
                pm.put("owned_by", "pollinations");
                items.add(pm);
            } catch (Exception ignored) {
            }
        }

        if (items.isEmpty()) {
            String msg = problems.isEmpty() ? "Не задан ни один ключ" : join(problems);
            return new Result(502, "{\"error\":{\"message\":" + JSONObject.quote(msg) + "}}", "application/json");
        }

        JSONArray arr = new JSONArray();
        for (JSONObject m : items) arr.put(m);
        JSONObject out = new JSONObject();
        try {
            out.put("object", "list");
            out.put("data", arr);
        } catch (Exception ignored) {
        }
        String json = out.toString();
        modelsCache = json;
        modelsCacheAt = System.currentTimeMillis();
        return new Result(200, json, "application/json");
    }

    // ------------------------------------------------------------------ post

    static Result post(String sub, String body) {
        if (body == null) body = "{}";

        JSONObject payload;
        try {
            payload = new JSONObject(body);
        } catch (Exception e) {
            payload = new JSONObject();
        }

        String model = payload.optString("model", "");
        boolean toGemini = GEMINI_KEY.length() > 0 && GEMINI_RE.matcher(model).find() && !geminiBlocked();

        if (toGemini) {
            String clean = model.replaceFirst("^models/", "");
            try {
                payload.put("model", clean);
            } catch (Exception ignored) {
            }
            if (sub.startsWith("/images/generations")) {
                try {
                    if (!payload.has("response_format")) payload.put("response_format", "b64_json");
                    payload.remove("size");
                } catch (Exception ignored) {
                }
            }

            String out = payload.toString();
            Result r = exec(GEMINI_BASE + sub, GEMINI_KEY, "POST", out, 300000);
            if (r.code < 400) return r;

            // Модель могла быть выведена из эксплуатации — пробуем актуальную.
            String err = errorText(r.body).toLowerCase();
            if ((r.code == 404 || r.code == 400) && err.contains("no longer available")) {
                try {
                    payload.put("model", FALLBACK_MODEL);
                } catch (Exception ignored) {
                }
                Result retry = exec(GEMINI_BASE + sub, GEMINI_KEY, "POST", payload.toString(), 300000);
                if (retry.code < 400) return retry;
                r = retry;
            }

            String low = errorText(r.body).toLowerCase();
            if (isGeo(low)) blockGemini(3600000L);
            if (!sub.startsWith("/chat/completions")) return r;

            Result poll = exec(POLL_BASE + "/openai", null, "POST", withModel(payload, POLL_MODEL), 300000);
            if (poll.code < 400) return poll;

            if (DARK_KEY.length() == 0) return r;

            String fallback = darkPick(payload);
            if (fallback != null) {
                try {
                    payload.put("model", fallback);
                } catch (Exception ignored) {
                }
                Result r2 = exec(DARK_BASE + sub, DARK_KEY, "POST", payload.toString(), 300000);
                if (r2.code < 400) return r2;
            }
            return r;
        }

        if (sub.startsWith("/chat/completions")) {
            Result poll = exec(POLL_BASE + "/openai", null, "POST", withModel(payload, POLL_MODEL), 300000);
            if (poll.code < 400) return poll;
        }
        return exec(DARK_BASE + sub, DARK_KEY, "POST", body, 300000);
    }

    /**
     * Стриминг ответа (SSE) без буферизации: чем раньше придёт первый токен,
     * тем раньше пользователь увидит текст.
     *
     * @return true — поток уже отдан (или начат); false — соединение с сервисом
     *         не удалось, вызывающий должен отправить обычную JSON-ошибку.
     */
    static boolean stream(String sub, String body, OutputStream raw) {
        HttpURLConnection c = null;
        boolean started = false;
        try {
            JSONObject payload = new JSONObject(body == null ? "{}" : body);
            String model = payload.optString("model", "");

            if (GEMINI_KEY.length() > 0 && GEMINI_RE.matcher(model).find()) {
                payload.put("model", model.replaceFirst("^models/", ""));
                c = connect(GEMINI_BASE + sub, GEMINI_KEY, payload.toString(), 20000, 300000);
                if (c.getResponseCode() >= 400) {
                    c.disconnect();
                    c = null;
                    if (DARK_KEY.length() > 0) {
                        String fallback = darkPick(payload);
                        if (fallback != null) {
                            payload.put("model", fallback);
                            c = connect(DARK_BASE + sub, DARK_KEY, payload.toString(), 15000, 300000);
                            if (c.getResponseCode() >= 400) {
                                c.disconnect();
                                c = null;
                            }
                        }
                    }
                    if (c == null) return false;
                }
            } else {
                c = connect(DARK_BASE + sub, DARK_KEY, body, 15000, 300000);
                if (c.getResponseCode() >= 400) {
                    c.disconnect();
                    return false;
                }
            }

            // Провайдер без SSE (например, запасной API) может вернуть обычный JSON —
            // отдаём его как есть, страница разберёт ответ сама.
            String ctype = c.getContentType();
            if (ctype == null || ctype.toLowerCase().indexOf("text/event-stream") < 0) {
                byte[] json = readAll(c.getInputStream()).getBytes(StandardCharsets.UTF_8);
                String plain = "HTTP/1.1 200 OK\r\n"
                        + "Content-Type: application/json; charset=utf-8\r\n"
                        + "Content-Length: " + json.length + "\r\n"
                        + "Connection: close\r\n\r\n";
                raw.write(plain.getBytes(StandardCharsets.UTF_8));
                raw.write(json);
                raw.flush();
                return true;
            }

            String head = "HTTP/1.1 200 OK\r\n"
                    + "Content-Type: text/event-stream; charset=utf-8\r\n"
                    + "Cache-Control: no-store\r\n"
                    + "X-Accel-Buffering: no\r\n"
                    + "Connection: close\r\n\r\n";
            raw.write(head.getBytes(StandardCharsets.UTF_8));
            raw.flush();
            started = true;

            InputStream in = c.getInputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) {
                raw.write(buf, 0, n);
                raw.flush();
            }
            return true;
        } catch (Exception e) {
            return started;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static HttpURLConnection connect(String url, String key, String body,
                                             int connectTimeout, int readTimeout) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(connectTimeout);
        c.setReadTimeout(readTimeout);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("Accept", "text/event-stream");
        c.setRequestProperty("User-Agent", UA);
        if (key != null && key.length() > 0) {
            c.setRequestProperty("Authorization", "Bearer " + key);
        }
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        byte[] data = body.getBytes(StandardCharsets.UTF_8);
        c.setFixedLengthStreamingMode(data.length);
        OutputStream os = c.getOutputStream();
        os.write(data);
        os.flush();
        os.close();
        return c;
    }


    /** Прогрев кэша списка моделей в фоне: первый запрос пользователя не ждёт сеть. */
    static void warmUp() {
        try {
            models();
        } catch (Exception ignored) {
        }
    }

    interface Sink {
        void chunk(String text);

        void done();

        void error(String message);
    }

    /** Стриминг чата напрямую в JS-мост: локальный HTTP-сервер не нужен. */
    static void streamChat(String body, Sink sink) {
        JSONObject payload;
        try {
            payload = new JSONObject(body == null ? "{}" : body);
        } catch (Exception e) {
            payload = new JSONObject();
        }

        String model = payload.optString("model", "");
        boolean toGemini = GEMINI_KEY.length() > 0
                && GEMINI_RE.matcher(model).find() && !geminiBlocked();

        List<String[]> attempts = new ArrayList<String[]>();
        if (toGemini) {
            attempts.add(new String[]{GEMINI_BASE + "/chat/completions", GEMINI_KEY,
                    withModel(payload, model.replaceFirst("^models/", ""))});
        }
        attempts.add(new String[]{POLL_BASE + "/openai", null, withModel(payload, POLL_MODEL)});
        if (DARK_KEY.length() > 0) {
            String fallback = darkPick(payload);
            if (fallback != null) {
                attempts.add(new String[]{DARK_BASE + "/chat/completions", DARK_KEY,
                        withModel(payload, fallback)});
            }
        }

        StringBuilder errors = new StringBuilder();
        for (String[] attempt : attempts) {
            HttpURLConnection c = null;
            try {
                c = connect(attempt[0], attempt[1], attempt[2], 20000, 300000);
                int code = c.getResponseCode();
                if (code >= 400) {
                    String raw = readAll(c.getErrorStream());
                    c.disconnect();
                    c = null;
                    String msg = errorText(raw);
                    if (msg.length() == 0) msg = "HTTP " + code;
                    if (isGeo(msg)) blockGemini(3600000L);
                    if (errors.length() > 0) errors.append("; ");
                    errors.append(msg);
                    continue;
                }

                java.io.Reader reader = new java.io.InputStreamReader(
                        c.getInputStream(), StandardCharsets.UTF_8);
                char[] buf = new char[1024];
                int n;
                while ((n = reader.read(buf)) > 0) {
                    sink.chunk(new String(buf, 0, n));
                }
                sink.done();
                return;
            } catch (Exception e) {
                if (errors.length() > 0) errors.append("; ");
                errors.append(String.valueOf(e.getMessage()));
            } finally {
                if (c != null) c.disconnect();
            }
        }
        sink.error(errors.length() > 0 ? errors.toString() : "нет доступных провайдеров");
    }

    /** Разбор PDF, аудио и других файлов нативным Gemini (inline_data). */
    static String inline(String mime, String b64, String prompt) throws Exception {
        String[] chain = {"gemini-3.5-flash", "gemini-flash-latest", "gemini-3.1-flash-lite"};
        String last = "";
        for (String model : chain) {
            JSONObject body = new JSONObject();
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", prompt));
            parts.put(new JSONObject().put("inline_data",
                    new JSONObject().put("mime_type", mime).put("data", b64)));
            body.put("contents", new JSONArray().put(
                    new JSONObject().put("role", "user").put("parts", parts)));

            java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
                    .openConnection();
            c.setConnectTimeout(20000);
            c.setReadTimeout(240000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("x-goog-api-key", GEMINI_KEY);
            byte[] raw = body.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(raw.length);
            java.io.OutputStream os = c.getOutputStream();
            os.write(raw);
            os.flush();
            os.close();

            int code = c.getResponseCode();
            String resp = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            c.disconnect();

            if (code >= 400) {
                String e = errorText(resp);
                last = e.length() > 0 ? e : ("HTTP " + code);
                continue;
            }
            try {
                JSONObject json = new JSONObject(resp);
                JSONArray cands = json.optJSONArray("candidates");
                if (cands == null || cands.length() == 0) { last = "пустой ответ"; continue; }
                JSONObject content = cands.getJSONObject(0).optJSONObject("content");
                JSONArray ps2 = content == null ? null : content.optJSONArray("parts");
                StringBuilder sb = new StringBuilder();
                for (int i = 0; ps2 != null && i < ps2.length(); i++) {
                    sb.append(ps2.getJSONObject(i).optString("text", ""));
                }
                String text = sb.toString().trim();
                if (text.length() > 0) return text;
                last = "модель не вернула текст";
            } catch (Exception e) {
                last = "непонятный ответ: " + e.getMessage();
            }
        }
        throw new Exception(last.length() > 0 ? last : "не удалось прочитать файл");
    }

    private static String darkPick(JSONObject payload) {
        if (darkIds == null) {
            List<String> ids = new ArrayList<String>();
            Result r = exec(DARK_BASE + "/models", DARK_KEY, "GET", null, 60000);
            if (r.code == 200) {
                try {
                    JSONArray data = new JSONObject(r.body).optJSONArray("data");
                    for (int i = 0; data != null && i < data.length(); i++) {
                        ids.add(data.getJSONObject(i).optString("id", ""));
                    }
                } catch (Exception ignored) {
                }
            }
            if (ids.isEmpty()) return null;
            darkIds = ids;
        }

        boolean vision = false;
        JSONArray msgs = payload.optJSONArray("messages");
        for (int i = 0; msgs != null && i < msgs.length(); i++) {
            JSONObject m = msgs.optJSONObject(i);
            if (m != null && m.opt("content") instanceof JSONArray) vision = true;
        }

        String[] rules = vision
                ? new String[]{"haiku", "sonnet", "gemini.*flash"}
                : new String[]{"deepseek.*flash", "flash|haiku|mini"};

        for (String rule : rules) {
            Pattern p = Pattern.compile(rule, Pattern.CASE_INSENSITIVE);
            for (String id : darkIds) {
                Matcher m = p.matcher(id);
                if (m.find()) return id;
            }
        }
        return darkIds.isEmpty() ? null : darkIds.get(0);
    }

    private static String join(List<String> parts) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) sb.append("; ");
            sb.append(parts.get(i));
        }
        return sb.toString();
    }
}
