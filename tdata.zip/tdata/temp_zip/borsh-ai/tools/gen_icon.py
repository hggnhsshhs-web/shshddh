#!/usr/bin/env python3
"""Иконки приложения из art/logo-src.png: обычные mipmap + adaptive (foreground)."""
import os

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
RES = os.path.join(ROOT, "res")
SRC = os.path.join(ROOT, "art", "logo-src.png")

DENSITY = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
FG_ZOOM = 0.68          # логотип занимает ~68% безопасной зоны адаптивной иконки

ADAPTIVE_XML = """<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/icon_bg" />
    <foreground android:drawable="@mipmap/ic_launcher_fg" />
</adaptive-icon>
"""

COLORS_XML = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="icon_bg">#000000</color>
</resources>
"""


def square(img):
    side = max(img.size)
    canvas = Image.new("RGB", (side, side), (0, 0, 0))
    canvas.paste(img, ((side - img.width) // 2, (side - img.height) // 2))
    return canvas


def main():
    src = Image.open(SRC).convert("RGB")
    base = square(src)

    for bucket, scale in DENSITY.items():
        folder = os.path.join(RES, "mipmap-" + bucket)
        os.makedirs(folder, exist_ok=True)

        size = int(round(48 * scale))
        base.resize((size, size), Image.LANCZOS).save(
            os.path.join(folder, "ic_launcher.png"), "PNG")

        # foreground для adaptive-icon: 108dp, логотип по центру на прозрачном фоне
        canvas_size = int(round(108 * scale))
        logo_size = int(round(canvas_size * FG_ZOOM))
        fg = Image.new("RGBA", (canvas_size, canvas_size), (0, 0, 0, 0))
        logo = base.resize((logo_size, logo_size), Image.LANCZOS).convert("RGBA")
        fg.paste(logo, ((canvas_size - logo_size) // 2, (canvas_size - logo_size) // 2))
        fg.save(os.path.join(folder, "ic_launcher_fg.png"), "PNG")

        print("mipmap-%s: %d/%d px" % (bucket, size, canvas_size))

    anydpi = os.path.join(RES, "mipmap-anydpi-v26")
    os.makedirs(anydpi, exist_ok=True)
    with open(os.path.join(anydpi, "ic_launcher.xml"), "w", encoding="utf-8") as f:
        f.write(ADAPTIVE_XML)

    values = os.path.join(RES, "values")
    os.makedirs(values, exist_ok=True)
    with open(os.path.join(values, "colors.xml"), "w", encoding="utf-8") as f:
        f.write(COLORS_XML)

    # картинка для шапки приложения
    header = os.path.join(ROOT, "assets", "logo.png")
    base.resize((192, 192), Image.LANCZOS).save(header, "PNG")
    print("assets/logo.png 192x192")


if __name__ == "__main__":
    main()
