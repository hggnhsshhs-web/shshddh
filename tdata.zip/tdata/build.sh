#!/usr/bin/env bash
# Сборка APK без Gradle: javac -> d8 -> aapt2 -> zipalign -> apksigner
set -euo pipefail

PROJ="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK:-$HOME/android}"
BT="$SDK/android-16"                 # build-tools 36.0.0
JAR="$SDK/android-34/android.jar"
OUT="$PROJ/build/borsh ai.apk"

# javac/keytool могут быть не в PATH — ищем JDK явно
if ! command -v javac >/dev/null 2>&1; then
  for candidate in "$SDK"/jdk-*/bin /usr/lib/jvm/*/bin; do
    if [ -x "$candidate/javac" ]; then
      export JAVA_HOME="$(dirname "$candidate")"
      export PATH="$candidate:$PATH"
      break
    fi
  done
fi
command -v javac >/dev/null 2>&1 || { echo "Нет javac — установи JDK 17+"; exit 1; }

for tool in aapt2 d8 apksigner zipalign; do
  [ -x "$BT/$tool" ] || { echo "Нет $BT/$tool — укажи ANDROID_SDK"; exit 1; }
done
[ -f "$JAR" ] || { echo "Нет $JAR"; exit 1; }

echo "== 1/8 проверка JS"
python3 - "$PROJ/assets/index.html" <<'PY'
import re, subprocess, sys, tempfile, os, shutil
html = open(sys.argv[1], encoding="utf-8").read()
blocks = re.findall(r"<script>(.*?)</script>", html, re.S)
node = shutil.which("node")
if not node:
    print("   node не найден, пропуск"); raise SystemExit(0)
for i, b in enumerate(blocks):
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as f:
        f.write(b); path = f.name
    r = subprocess.run([node, "--check", path], capture_output=True, text=True)
    os.unlink(path)
    if r.returncode != 0:
        print("   ОШИБКА в блоке", i + 1); print(r.stderr[:800]); raise SystemExit(1)
print("   блоков script:", len(blocks), "— синтаксис OK")
PY

echo "== 2/8 иконки"
python3 "$PROJ/tools/gen_icon.py" >/dev/null

echo "== 3/8 чистка"
rm -rf "$PROJ/build"
mkdir -p "$PROJ/build/classes" "$PROJ/build/dex"

echo "== 4/8 javac"
javac -encoding UTF-8 -nowarn -source 11 -target 11 -classpath "$JAR" \
  -d "$PROJ/build/classes" $(find "$PROJ/src" -name '*.java')

echo "== 5/8 d8"
"$BT/d8" --release --min-api 24 --lib "$JAR" \
  --output "$PROJ/build/dex" $(find "$PROJ/build/classes" -name '*.class')

echo "== 6/8 aapt2"
"$BT/aapt2" compile --dir "$PROJ/res" -o "$PROJ/build/res.zip"
"$BT/aapt2" link -o "$PROJ/build/base.apk" -I "$JAR" \
  --manifest "$PROJ/AndroidManifest.xml" \
  --min-sdk-version 24 --target-sdk-version 34 \
  -A "$PROJ/assets" "$PROJ/build/res.zip"

echo "== 7/8 dex + zipalign"
python3 - "$PROJ/build/base.apk" "$PROJ/build/dex/classes.dex" <<'PY'
import sys, zipfile, shutil
apk, dex = sys.argv[1], sys.argv[2]
tmp = apk + ".tmp"
with zipfile.ZipFile(apk) as src, zipfile.ZipFile(tmp, "w") as dst:
    for item in src.infolist():
        dst.writestr(item, src.read(item.filename))
    dst.write(dex, "classes.dex", compress_type=zipfile.ZIP_STORED)
shutil.move(tmp, apk)
PY
"$BT/zipalign" -f 4 "$PROJ/build/base.apk" "$PROJ/build/aligned.apk"

echo "== 8/8 подпись"
KS="$PROJ/keystore.jks"   # хранится в проекте, чтобы обновления ставились поверх
if [ ! -f "$KS" ]; then
  keytool -genkeypair -v -keystore "$KS" -alias borsh -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass android -keypass android \
    -dname "CN=Borsh AI, O=Personal, C=RU" >/dev/null 2>&1
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias borsh \
  --ks-pass pass:android --key-pass pass:android \
  --min-sdk-version 24 --out "$OUT" "$PROJ/build/aligned.apk"
"$BT/apksigner" verify --print-certs "$OUT" | head -4

echo
echo "Готово: $OUT"
ls -lh "$OUT" | awk '{print $5}'
