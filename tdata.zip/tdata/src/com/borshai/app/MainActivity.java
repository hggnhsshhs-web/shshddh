package com.borshai.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String TAG = "BorshAI";
    private static final String PAGE = "file:///android_asset/index.html";
    private static final int REQ_FILE = 1001;
    private static final int REQ_SPEECH = 1002;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private TextToSpeech tts;
    private long lastLoad = 0;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        // Имерсивный дизайн: статус-бар и навигация в цвет приложения
        if (Build.VERSION.SDK_INT >= 21) {
            Window w = getWindow();
            w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
            w.setStatusBarColor(0xFF060607);
            if (Build.VERSION.SDK_INT >= 26) {
                w.setNavigationBarColor(0xFF060607);
            }
        }

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        web.setBackgroundColor(0xFF060607);
        web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Native(), "Native");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame()) {
                    Log.e(TAG, "load error: " + error.getDescription());
                    showDiagnostic("Страница не загрузилась: " + error.getDescription());
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Log.e(TAG, "load error " + errorCode + ": " + description + " " + failingUrl);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(android.webkit.ConsoleMessage msg) {
                Log.d(TAG, "js: " + msg.message());
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, REQ_FILE);
                    return true;
                } catch (Exception e) {
                    fileCallback = null;
                    toast("Не удалось открыть выбор файлов", true);
                    return false;
                }
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                result.confirm();
                            }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface d) {
                                result.cancel();
                            }
                        })
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                result.confirm();
                            }
                        })
                        .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface d, int w) {
                                result.cancel();
                            }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override
                            public void onCancel(DialogInterface d) {
                                result.cancel();
                            }
                        })
                        .show();
                return true;
            }
        });

        setContentView(web);

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS && tts != null) {
                    try {
                        tts.setLanguage(Locale.getDefault());
                    } catch (Exception ignored) {
                    }
                }
            }
        });

        loadPage();
        handleIncoming(getIntent());
        verifyPageLoaded();
    }

    /** Если интерфейс не поднялся — показываем текст ошибки, а не чёрный экран. */
    private void verifyPageLoaded() {
        web.postDelayed(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(
                        "document.getElementById('chat') ? 'ok' : 'empty'",
                        new ValueCallback<String>() {
                            @Override
                            public void onReceiveValue(String value) {
                                if (value != null && value.indexOf("empty") >= 0) {
                                    showDiagnostic("Интерфейс не загрузился. Попробуйте перезагрузить.");
                                }
                            }
                        });
            }
        }, 4000);
    }

    private void loadPage() {
        lastLoad = System.currentTimeMillis();
        web.loadUrl(PAGE);
    }

    private void showDiagnostic(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String html = "<html><head><meta name='viewport' content='width=device-width'>"
                        + "<style>body{background:#060607;color:#f4f4f7;font:16px system-ui;padding:28px;"
                        + "line-height:1.5}h1{font-size:19px;margin:0 0 10px}p{color:#b9b9c6;font-size:14px}"
                        + "button{margin-top:18px;padding:12px 18px;border-radius:12px;border:0;"
                        + "background:linear-gradient(135deg,#ff2b3d,#ff6a3d);color:#fff;font-size:15px}"
                        + "</style></head><body><h1>borsh ai</h1><p>"
                        + message.replace("<", "&lt;")
                        + "</p><button onclick='location.href=\"" + PAGE + "\"'>Перезагрузить</button>"
                        + "</body></html>";
                web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // если приложение свернули во время загрузки — перезагрузим пустую страницу
        if (web != null && web.getUrl() == null) loadPage();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_SPEECH) {
            if (res == RESULT_OK && data != null) {
                ArrayList<String> heard = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (heard != null && !heard.isEmpty()) {
                    final String text = heard.get(0);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            web.evaluateJavascript("window.__voice(" + JSONObject.quote(text) + ")", null);
                        }
                    });
                }
            }
            return;
        }
        if (req == REQ_FILE) {
            if (fileCallback != null) {
                Uri[] result = null;
                if (res == RESULT_OK && data != null) {
                    if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        result = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            result[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        result = new Uri[]{data.getData()};
                    }
                }
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("typeof window.onBackPressed === 'function' && window.onBackPressed()", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (web.canGoBack()) {
                                web.goBack();
                            } else {
                                MainActivity.super.onBackPressed();
                            }
                        }
                    });
                }
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIncoming(intent);
    }

    /** Текст, которым поделились из другого приложения, попадает в поле ввода. */
    private void handleIncoming(Intent intent) {
        if (intent == null || web == null) return;
        if (!Intent.ACTION_SEND.equals(intent.getAction())) return;
        final String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text == null || text.length() == 0) return;
        web.postDelayed(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript("window.__shared && window.__shared(" + JSONObject.quote(text) + ")", null);
            }
        }, 700);
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    // --------------------------------------------------------------- мост JS

    private void deliver(final String js) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    public class Native {

        @JavascriptInterface
        public void apiModels(final String id) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Proxy.Result r = Proxy.models();
                    deliver("window.__api.models(" + JSONObject.quote(id) + ","
                            + (r.code < 400) + "," + JSONObject.quote(r.body) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public void apiChat(final String body, final String id) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Proxy.streamChat(body, new Proxy.Sink() {
                            @Override
                            public void chunk(String text) {
                                deliver("window.__api.chatDelta(" + JSONObject.quote(id) + ","
                                        + JSONObject.quote(text) + ")");
                            }

                            @Override
                            public void done() {
                                deliver("window.__api.chatEnd(" + JSONObject.quote(id) + ")");
                            }

                            @Override
                            public void error(String message) {
                                deliver("window.__api.chatError(" + JSONObject.quote(id) + ","
                                        + JSONObject.quote(message) + ")");
                            }
                        });
                    } catch (Exception e) {
                        deliver("window.__api.chatError(" + JSONObject.quote(id) + ","
                                + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void apiImage(final String body, final String id) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Proxy.Result r = Proxy.post("/images/generations", body);
                    deliver("window.__api.image(" + JSONObject.quote(id) + ","
                            + (r.code < 400) + "," + JSONObject.quote(r.body) + ")");
                }
            }).start();
        }

        @JavascriptInterface
        public void apiInline(final String mime, final String b64, final String prompt, final String id) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        String text = Proxy.inline(mime, b64, prompt);
                        deliver("window.__api.inline(" + JSONObject.quote(id) + ",true,"
                                + JSONObject.quote(text) + ")");
                    } catch (Exception e) {
                        deliver("window.__api.inline(" + JSONObject.quote(id) + ",false,"
                                + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void apiLogin(final String email, final String pass, final String id) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    Log.d(TAG, "Login attempt: " + email);
                    try {
                        Thread.sleep(800); // Simulate network
                        deliver("window.__api.login(" + JSONObject.quote(id) + ",true,'{\"token\":\"mock\"}')");
                    } catch (Exception e) {
                        deliver("window.__api.login(" + JSONObject.quote(id) + ",false,"
                                + JSONObject.quote(String.valueOf(e.getMessage())) + ")");
                    }
                }
            }).start();
        }

        @JavascriptInterface
        public void speak(final String text) {
            if (tts == null || text == null) return;
            String plain = text.replaceAll("```[\\s\\S]*?```", " код ")
                    .replaceAll("[#*`>|]", " ")
                    .replaceAll("\\s+", " ")
                    .trim();
            if (plain.length() > 4000) plain = plain.substring(0, 4000);
            tts.speak(plain, TextToSpeech.QUEUE_FLUSH, null, "borsh");
        }

        @JavascriptInterface
        public void stopSpeak() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void listen() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите…");
                    try {
                        startActivityForResult(intent, REQ_SPEECH);
                    } catch (ActivityNotFoundException e) {
                        toast("На телефоне нет распознавания речи", true);
                    }
                }
            });
        }

        @JavascriptInterface
        public void speakEx(final String text, final float pitch, final float rate, final String lang) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (tts == null) return;
                    try {
                        if (lang != null && lang.length() > 1) tts.setLanguage(Locale.forLanguageTag(lang));
                        tts.setPitch(pitch <= 0 ? 1f : pitch);
                        tts.setSpeechRate(rate <= 0 ? 1f : rate);
                    } catch (Exception ignored) {
                    }
                    speak(text);
                }
            });
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_SEND);
                        intent.setType("text/plain");
                        intent.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(intent, "Поделиться"));
                    } catch (Exception e) {
                        toast("Не удалось поделиться", true);
                    }
                }
            });
        }

        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(Math.max(5, ms),
                            VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(Math.max(5, ms));
                }
            } catch (Exception ignored) {
            }
        }

        @JavascriptInterface
        public void saveImage(final String dataUrl, final String name) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        toast(writeImage(dataUrl, name), false);
                    } catch (Exception e) {
                        toast("Не удалось сохранить: " + e.getMessage(), true);
                    }
                }
            }).start();
        }
    }

    // ------------------------------------------------------------ сохранение

    private String writeImage(String dataUrl, String name) throws Exception {
        int comma = dataUrl.indexOf(',');
        if (comma < 0) throw new Exception("плохие данные");
        byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
        String fileName = (name == null || name.length() == 0 ? "borsh-ai.png" : name);
        if (!fileName.toLowerCase().endsWith(".png")) fileName = fileName + ".png";

        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + "/Borsh AI");
            Uri uri = getContentResolver()
                    .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("галерея недоступна");
            OutputStream os = getContentResolver().openOutputStream(uri);
            os.write(bytes);
            os.flush();
            os.close();
            return "Сохранено в галерею: Pictures/Borsh AI";
        }

        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        if (dir == null) throw new Exception("нет доступа к папке");
        if (!dir.exists() && !dir.mkdirs()) throw new Exception("нет доступа к папке");
        File out = new File(dir, fileName);
        FileOutputStream fos = new FileOutputStream(out);
        fos.write(bytes);
        fos.flush();
        fos.close();
        return "Сохранено: " + out.getAbsolutePath();
    }

    private void toast(final String message, final boolean error) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, message,
                        error ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT).show();
            }
        });
    }
}
